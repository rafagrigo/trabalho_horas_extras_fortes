/* ===================================
   HELPERS
=================================== */

function genId(){
  return 'id_' + Math.random().toString(36).slice(2,9);
}

function money(n){
  return 'R$ ' + Number(n)
    .toFixed(2)
    .replace('.',',')
    .replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

/* ===================================
   DADOS (DEFAULT + LOCALSTORAGE)
=================================== */

const DEFAULT_DATA = {
  aprovadas: [
    {
      id: genId(),
      periodo: 'Manhã',
      gestor: 'Carlos Silva',
      data: '15/11/2025',
      duracao: '08:00 - 12:00',
      horas: 4,
      valor: 120.00,
      obra: 'Equipamento A3',
      comentarios: 'Manutenção urgente no equipamento A3',
      status: 'Pendente'
    },
    {
      id: genId(),
      periodo: 'Tarde',
      gestor: 'Maria Santos',
      data: '16/11/2025',
      duracao: '14:00 - 17:00',
      horas: 3,
      valor: 90.00,
      obra: 'Obra Residencial Torres',
      comentarios: 'Instalação de novos componentes',
      status: 'Aprovado'
    },
    {
      id: genId(),
      periodo: 'Noite',
      gestor: 'Carlos Silva',
      data: '18/11/2025',
      duracao: '18:00 - 20:00',
      horas: 2,
      valor: 60.00,
      obra: 'Obra Industrial Norte',
      comentarios: 'Suporte técnico emergencial',
      status: 'Pendente'
    },
    {
      id: genId(),
      periodo: 'Manhã',
      gestor: 'Ana Costa',
      data: '20/11/2025',
      duracao: '09:00 - 14:00',
      horas: 5,
      valor: 150.00,
      obra: 'Treinamento da equipe',
      comentarios: 'Treinamento da equipe nova',
      status: 'Reprovado'
    }
  ],
  cumpridas: [
    {
      id: genId(),
      periodo: 'Manhã',
      gestor: 'Carlos Silva',
      data: '01/11/2025',
      duracao: '07:00 - 11:00',
      horas: 4,
      valor: 120.00,
      obra: 'Revisão geral do sistema',
      comentarios: 'Revisão completa do sistema',
      status: 'Realizado'
    },
    {
      id: genId(),
      periodo: 'Tarde',
      gestor: 'Maria Santos',
      data: '05/11/2025',
      duracao: '13:00 - 19:00',
      horas: 6,
      valor: 180.00,
      obra: 'Atualização de software',
      comentarios: 'Atualização de software crítico',
      status: 'Realizado'
    },
    {
      id: genId(),
      periodo: 'Noite',
      gestor: 'Ana Costa',
      data: '08/11/2025',
      duracao: '19:00 - 22:00',
      horas: 3,
      valor: 90.00,
      obra: 'Manutenção preventiva',
      comentarios: 'Manutenção preventiva',
      status: 'Realizado'
    }
  ]
};

const STORAGE_KEY = 'fortes_tecnico_horas_extra_v1';

function loadData(){
  const raw = localStorage.getItem(STORAGE_KEY);
  if(!raw){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_DATA));
    return JSON.parse(JSON.stringify(DEFAULT_DATA));
  }
  try{
    const parsed = JSON.parse(raw);
    return Object.assign({}, DEFAULT_DATA, parsed);
  }catch(e){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_DATA));
    return JSON.parse(JSON.stringify(DEFAULT_DATA));
  }
}

function saveData(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(DATA));
}

let DATA = loadData();

/* ===================================
   DOM
=================================== */

const pages = document.querySelectorAll('.page');

const tabelaAprovadasEl = document.getElementById('tabelaAprovadas');
const tabelaCumpridasEl = document.getElementById('tabelaCumpridas');

const totalHorasAprovadasEl = document.getElementById('totalHorasAprovadas');
const totalValorAprovadasEl = document.getElementById('totalValorAprovadas');
const totalHorasCumpridasEl = document.getElementById('totalHorasCumpridas');
const totalValorCumpridasEl = document.getElementById('totalValorCumpridas');

const userInfoBtn = document.getElementById('userInfoBtn');
const profileDropdown = document.getElementById('profileDropdown');
const btnSair = document.getElementById('btnSair');
const overlay = document.getElementById('overlay');

/* ===================================
   INIT
=================================== */

function init(){
  bindMenu();
  bindTopbar();
  bindPasswordModal();
  bindSupport();
  renderAll();
  navigateTo('aprovadas');
  if(window.feather) feather.replace();
}

init();

/* ===================================
   MENU / NAVEGAÇÃO
=================================== */

function bindMenu(){
  document.querySelectorAll('.menu-item').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const page = btn.dataset.page;
      document.querySelectorAll('.menu-item').forEach(m=>m.classList.remove('active'));
      btn.classList.add('active');
      navigateTo(page);
    });
  });
}

function navigateTo(page){
  pages.forEach(p=>{
    p.hidden = p.dataset.page !== page;
  });
  setActions(page);
  if(window.feather) feather.replace();
}

function createActionButton(containerId, icon, label, handler, isRefresh){
  const box = document.getElementById(containerId);
  if(!box) return null;

  const b = document.createElement('button');

  if(isRefresh){
    b.className = 'btn btn-refresh lift-sm';
    b.innerHTML = `
      <span class="refresh-icon-wrapper"><i data-feather="${icon}"></i></span>
      <span class="btn-label">${label}</span>
    `;
    b.addEventListener('click', ()=>{
      if(b.classList.contains('btn-refresh-anim')) return;

      b.classList.add('btn-refresh-anim');
      b.innerHTML = `
        <span class="refresh-icon-wrapper"><i data-feather="${icon}"></i></span>
        <span class="btn-label">
          ${label}
          <span class="dots"><span>.</span><span>.</span><span>.</span></span>
        </span>
      `;
      if(window.feather) feather.replace();

      handler();

      setTimeout(()=>{
        b.classList.remove('btn-refresh-anim');
        b.innerHTML = `
          <span class="refresh-icon-wrapper"><i data-feather="${icon}"></i></span>
          <span class="btn-label">${label}</span>
        `;
        if(window.feather) feather.replace();
      }, 900);
    });
  }else{
    b.className = 'btn btn-primary lift-sm';
    b.innerHTML = `<i data-feather="${icon}"></i> ${label}`;
    b.addEventListener('click', handler);
  }

  box.appendChild(b);
  return b;
}

function setActions(page){
  ['actions-aprovadas','actions-cumpridas'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.innerHTML = '';
  });

  if(page === 'aprovadas'){
    createActionButton('actions-aprovadas','refresh-cw','Atualizar', ()=>renderAll(), true);
    createActionButton('actions-aprovadas','download','Exportar CSV', ()=>exportCSV('aprovadas'), false);
  }else if(page === 'cumpridas'){
    createActionButton('actions-cumpridas','refresh-cw','Atualizar', ()=>renderAll(), true);
    createActionButton('actions-cumpridas','download','Exportar CSV', ()=>exportCSV('cumpridas'), false);
  }

  if(window.feather) feather.replace();
}

/* ===================================
   TOPBAR / PERFIL
=================================== */

function bindTopbar(){
  userInfoBtn.addEventListener('click', (e)=>{
    e.stopPropagation();
    toggleProfile(profileDropdown.classList.contains('hidden'));
  });

  window.addEventListener('click', (e)=>{
    if(!profileDropdown.classList.contains('hidden')){
      const inside = profileDropdown.contains(e.target) || userInfoBtn.contains(e.target);
      if(!inside) toggleProfile(false);
    }
  });

  btnSair.addEventListener('click', ()=>{
    alert('Logout efetuado (mock).');
  });
}

function toggleProfile(open){
  if(open){
    profileDropdown.classList.remove('hidden');
    userInfoBtn.setAttribute('aria-expanded','true');
  }else{
    profileDropdown.classList.add('hidden');
    userInfoBtn.setAttribute('aria-expanded','false');
  }
}

/* ===================================
   RENDERIZAÇÃO
=================================== */

function statusClass(status){
  switch(status){
    case 'Aprovado': return 'status-aprovado';
    case 'Reprovado': return 'status-reprovado';
    case 'Realizado': return 'status-realizado';
    default: return 'status-pendente';
  }
}

function renderAprovadas(){
  tabelaAprovadasEl.innerHTML = '';

  if(!DATA.aprovadas.length){
    const empty = document.createElement('div');
    empty.className = 'card';
    empty.textContent = 'Nenhuma hora extra aprovada.';
    tabelaAprovadasEl.appendChild(empty);
    return;
  }

  DATA.aprovadas.forEach(item=>{
    const row = document.createElement('div');
    row.className = 'table-row-card';
    row.innerHTML = `
      <div>${item.periodo}</div>
      <div>${item.gestor}</div>
      <div class="obra-wrap">${item.obra}</div>
      <div>${item.data}</div>
      <div>${item.duracao}</div>
      <div>${money(item.valor)}</div>
      <div class="obra-wrap">${item.comentarios}</div>
      <div>
        <span class="status-pill ${statusClass(item.status)}">${item.status}</span>
      </div>
    `;
    tabelaAprovadasEl.appendChild(row);
  });
}

function renderCumpridas(){
  tabelaCumpridasEl.innerHTML = '';

  if(!DATA.cumpridas.length){
    const empty = document.createElement('div');
    empty.className = 'card';
    empty.textContent = 'Nenhuma hora extra cumprida.';
    tabelaCumpridasEl.appendChild(empty);
    return;
  }

  DATA.cumpridas.forEach(item=>{
    const row = document.createElement('div');
    row.className = 'table-row-card';
    row.innerHTML = `
      <div>${item.periodo}</div>
      <div>${item.gestor}</div>
      <div class="obra-wrap">${item.obra}</div>
      <div>${item.data}</div>
      <div>${item.duracao}</div>
      <div>${money(item.valor)}</div>
      <div class="obra-wrap">${item.comentarios}</div>
      <div>
        <span class="status-pill ${statusClass(item.status || 'Realizado')}">
          ${item.status || 'Realizado'}
        </span>
      </div>
    `;
    tabelaCumpridasEl.appendChild(row);
  });
}

function atualizarResumos(){
  const totalHorasAprovadas = DATA.aprovadas.reduce((s,i)=> s + Number(i.horas || 0), 0);
  const totalValorAprovadas = DATA.aprovadas.reduce((s,i)=> s + Number(i.valor || 0), 0);

  totalHorasAprovadasEl.textContent = totalHorasAprovadas + 'h';
  totalValorAprovadasEl.textContent = money(totalValorAprovadas);

  const totalHorasCumpridas = DATA.cumpridas.reduce((s,i)=> s + Number(i.horas || 0), 0);
  const totalValorCumpridas = DATA.cumpridas.reduce((s,i)=> s + Number(i.valor || 0), 0);

  totalHorasCumpridasEl.textContent = totalHorasCumpridas + 'h';
  totalValorCumpridasEl.textContent = money(totalValorCumpridas);
}

function renderAll(){
  renderAprovadas();
  renderCumpridas();
  atualizarResumos();
  saveData();
  if(window.feather) feather.replace();
}

/* ===================================
   MODAIS GENÉRICOS (SUPORTE)
=================================== */

function showOverlay(){
  overlay.hidden = false;
  overlay.style.opacity = '1';
}

function hideOverlay(){
  overlay.hidden = true;
  overlay.style.opacity = '0';
}

function openModal(id){
  const el = document.getElementById(id);
  if(!el) return;
  el.hidden = false;
  showOverlay();
  if(window.feather) feather.replace();
}

function closeModal(id){
  const el = document.getElementById(id);
  if(!el) return;
  el.hidden = true;
  hideOverlay();
}

function bindSupport(){
  const btnSuporte = document.getElementById('btnSuporte');
  const suporteClose = document.getElementById('suporteClose');
  const btnMail = document.getElementById('btnMail');
  const btnWhats = document.getElementById('btnWhats');
  const copyEmail = document.getElementById('copyEmail');
  const copyTel = document.getElementById('copyTel');
  const suporteMsg = document.getElementById('suporteMsg');

  btnSuporte.addEventListener('click', ()=>openModal('modalSuporte'));
  suporteClose.addEventListener('click', ()=>closeModal('modalSuporte'));

  overlay.addEventListener('click', ()=>{
    const modalSuporte = document.getElementById('modalSuporte');
    if(modalSuporte && !modalSuporte.hidden) closeModal('modalSuporte');
  });

  copyEmail.addEventListener('click', ()=>navigator.clipboard.writeText('ti@fortes.eng'));
  copyTel.addEventListener('click', ()=>navigator.clipboard.writeText('(27) 99999-0000'));

  btnMail.addEventListener('click', ()=>{
    const body = encodeURIComponent(suporteMsg.value || '');
    const subject = encodeURIComponent('Suporte de TI');
    window.location.href = `mailto:ti@fortes.eng?subject=${subject}&body=${body}`;
  });

  btnWhats.addEventListener('click', ()=>{
    const msg = encodeURIComponent(suporteMsg.value || 'Olá, preciso de suporte.');
    window.open(`https://wa.me/5527999990000?text=${msg}`,'_blank');
  });
}

/* ===================================
   MODAL SENHA
=================================== */

function bindPasswordModal(){
  const modalPassword = document.getElementById('modalPassword');
  const newPassInput = document.getElementById('newPassword');
  const confirmPassInput = document.getElementById('confirmPassword');
  const saveBtn = document.getElementById('passwordSave');
  const err = document.getElementById('passwordError');
  const ok = document.getElementById('passwordOk');
  const toggles = document.querySelectorAll('#modalPassword .password-toggle');

  function setToggleIcon(toggle, input){
    if (!toggle || !input) return;
    const isVisible = input.type === 'text';
    const iconName = isVisible ? 'eye-off' : 'eye';
    toggle.innerHTML = `<i data-feather="${iconName}"></i>`;
  }

  function updatePasswordToggleVisibility(){
    toggles.forEach(toggle=>{
      const targetId = toggle.getAttribute('data-target');
      const targetInput = document.getElementById(targetId);

      if(targetInput && targetInput.value.trim().length > 0){
        toggle.hidden = false;
      }else{
        toggle.hidden = true;
        if(targetInput && targetInput.type === 'text'){
          targetInput.type = 'password';
        }
      }

      if(targetInput){
        setToggleIcon(toggle, targetInput);
      }
    });

    if(window.feather) feather.replace();
  }

  toggles.forEach(toggle=>{
    toggle.addEventListener('click', ()=>{
      const targetId = toggle.getAttribute('data-target');
      const input = document.getElementById(targetId);
      if(!input) return;
      input.type = input.type === 'password' ? 'text' : 'password';
      setToggleIcon(toggle, input);
      if(window.feather) feather.replace();
    });
  });

  document.getElementById('openPassword').onclick = ()=>{
    toggleProfile(false);
    err.hidden = true;
    ok.hidden = true;
    newPassInput.value = '';
    confirmPassInput.value = '';
    saveBtn.disabled = true;
    updatePasswordToggleVisibility();
    modalPassword.classList.add('show');
  };

  document.getElementById('passwordClose').onclick = ()=>modalPassword.classList.remove('show');

  modalPassword.addEventListener('click',(e)=>{
    if(e.target === modalPassword) modalPassword.classList.remove('show');
  });

  function validatePasswordFields(){
    const a = newPassInput.value.trim();
    const b = confirmPassInput.value.trim();

    updatePasswordToggleVisibility();
    err.hidden = true;
    ok.hidden = true;

    if(!a || !b){
      saveBtn.disabled = true;
      return;
    }

    if(a !== b){
      err.textContent = 'As senhas não coincidem.';
      err.hidden = false;
      saveBtn.disabled = true;
      return;
    }

    saveBtn.disabled = false;
  }

  newPassInput.addEventListener('input', validatePasswordFields);
  confirmPassInput.addEventListener('input', validatePasswordFields);

  document.getElementById('passwordForm').addEventListener('submit', (e)=>{
    e.preventDefault();

    const a = newPassInput.value.trim();
    const b = confirmPassInput.value.trim();

    err.hidden = true;
    ok.hidden = true;

    if(!a || !b || a !== b){
      err.textContent = 'As senhas não coincidem.';
      err.hidden = false;
      saveBtn.disabled = true;
      return;
    }

    saveBtn.disabled = true;
    ok.textContent = 'Senha alterada com sucesso!';
    ok.hidden = false;

    setTimeout(()=>modalPassword.classList.remove('show'), 900);
  });
}

/* ===================================
   ESC fecha modais
=================================== */

window.addEventListener('keydown', (e)=>{
  if(e.key === 'Escape'){
    const modalSuporte = document.getElementById('modalSuporte');
    if(modalSuporte && !modalSuporte.hidden){
      closeModal('modalSuporte');
    }
    const modalPassword = document.getElementById('modalPassword');
    if(modalPassword && modalPassword.classList.contains('show')){
      modalPassword.classList.remove('show');
    }
  }
});

/* ===================================
   EXPORT CSV
=================================== */

function exportCSV(page){
  let rows = [];

  if(page === 'aprovadas'){
    rows.push(['Horário','Gestor','Obra','Data','Duração','Valor','Comentários','Status']);
    DATA.aprovadas.forEach(i=>{
      rows.push([
        i.periodo,
        i.gestor,
        i.obra,
        i.data,
        i.duracao,
        money(i.valor),
        i.comentarios,
        i.status
      ]);
    });
  }else if(page === 'cumpridas'){
    rows.push(['Horário','Gestor','Obra','Data','Duração','Valor','Comentários','Status']);
    DATA.cumpridas.forEach(i=>{
      rows.push([
        i.periodo,
        i.gestor,
        i.obra,
        i.data,
        i.duracao,
        money(i.valor),
        i.comentarios,
        i.status || 'Realizado'
      ]);
    });
  }

  const csv = rows
    .map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(','))
    .join('\n');

  const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${page}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
