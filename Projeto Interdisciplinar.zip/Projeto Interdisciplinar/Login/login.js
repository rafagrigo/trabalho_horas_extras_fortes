// Rotas simuladas por cargo (ajuste para as reais do seu projeto):
const ROUTES = {
  tecnico: 'dashboard_tecnico.html',
  encarregado: 'dashboard_encarregado.html',
  gestor: 'dashboard_gestor.html'
};

let currentRole = 'tecnico';

// Helpers
const $  = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

function setActiveRole(btn){
  $$('.role-card').forEach(b=>{
    b.classList.remove('active');
    b.setAttribute('aria-pressed','false');
  });
  btn.classList.add('active');
  btn.setAttribute('aria-pressed','true');
  currentRole = btn.dataset.role;
}

function switchTab(tab){
  $$('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
  $$('.form').forEach(f => f.classList.remove('show'));
  (tab === 'login' ? $('#form-login') : $('#form-register')).classList.add('show');
}

// Eventos UI
$$('.role-card').forEach(btn => btn.addEventListener('click', () => setActiveRole(btn)));
$$('.tab').forEach(t => t.addEventListener('click', () => switchTab(t.dataset.tab)));

switchTab('login'); // padrão

// ===== Animação Entrar (loading) =====
$('#form-login').addEventListener('submit', (e) => {
  e.preventDefault();
  const userOrEmail = $('#login-email').value.trim();
  const pass  = $('#login-pass').value.trim();
  if(!userOrEmail){ alert('Informe seu usuário ou email.'); return; }
  if(!pass){ alert('Informe sua senha.'); return; }

  const btn = $('#login-submit');
  btn.classList.add('loading');
  btn.disabled = true;

  // Simula chamada à API + redirecionamento
  setTimeout(() => {
    localStorage.setItem('fe:userRole', currentRole);
    window.location.href = ROUTES[currentRole] || 'index.html';
  }, 1200);
});

// ===== Cadastrar (boas-vindas) =====
$('#form-register').addEventListener('submit', (e) => {
  e.preventDefault();

  const name = $('#reg-name').value.trim();
  const mail = $('#reg-email').value.trim();
  const tel  = $('#reg-phone').value.trim();
  const p1   = $('#reg-pass').value.trim();
  const p2   = $('#reg-pass2').value.trim();

  if(!name || !mail || !p1 || !p2){
    alert('Preencha todos os campos obrigatórios.');
    return;
  }
  if(p1 !== p2){
    alert('As senhas não coincidem.');
    return;
  }

  // Sucesso simulado -> animação de boas-vindas
  const overlay = $('#welcome-overlay');
  overlay.classList.add('show');

  // Fecha overlay e volta para o login
  setTimeout(() => {
    overlay.classList.remove('show');
    switchTab('login');
    $('#login-email').value = mail;
    $('#login-pass').value = '';
  }, 1700);
});