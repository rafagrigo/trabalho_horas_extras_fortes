// Variáveis globais
let currentTech = '';

// Navegação
function navigateTo(page) {
    // Oculta todas as páginas
    document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
    
    // Mostra a página selecionada
    document.getElementById('page-' + page).classList.remove('hidden');
    
    // Atualiza menu ativo
    document.querySelectorAll('.menu-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === page) {
            item.classList.add('active');
        }
    });
}

// Event listeners para menu (garante que a navegação funcione ao carregar a página)
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', () => {
            navigateTo(item.dataset.page);
        });
    });
});


// Toggle menu mobile
function toggleMenu() {
    const menuTitle = document.querySelector('.menu-title');
    const menuItems = document.querySelector('.menu-items');
    menuTitle.classList.toggle('expanded');
    menuItems.classList.toggle('show');
}

// Modais
function openModal(modalId) {
    document.getElementById(modalId).classList.add('show');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

function openConfirmModal(techName) {
    currentTech = techName;
    document.getElementById('confirm-tech-name').textContent = techName;
    openModal('modal-confirm');
}

function openFormModal() {
    closeModal('modal-confirm');
    // Transfere o nome do técnico para o modal de formulário
    document.getElementById('form-tech-name').textContent = currentTech; 
    openModal('modal-form');
}

function openCancelModal(techName) {
    currentTech = techName;
    document.getElementById('cancel-tech-name').textContent = techName;
    openModal('modal-cancel');
}

function confirmCancel() {
    alert('Solicitação cancelada com sucesso!');
    closeModal('modal-cancel');
}

// Fechar modal ao clicar fora
document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            overlay.classList.remove('show');
        }
    });
});

// Máscara de data
document.addEventListener('DOMContentLoaded', () => {
    const dateInput = document.getElementById('date-input');
    if (dateInput) {
        dateInput.addEventListener('input', (e) => {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length >= 2) {
                value = value.slice(0, 2) + '/' + value.slice(2);
            }
            if (value.length >= 5) {
                value = value.slice(0, 5) + '/' + value.slice(5, 9);
            }
            e.target.value = value;
        });
    }
    
    // Configura o evento de submit do formulário
    const overtimeForm = document.getElementById('overtime-form');
    if (overtimeForm) {
        overtimeForm.addEventListener('submit', (e) => {
            e.preventDefault();
            alert('Solicitação enviada com sucesso para ' + currentTech + '!');
            closeModal('modal-form');
            e.target.reset();
        });
    }
});


// Botões de navegação
function goBack() {
    alert('Funcionalidade de voltar');
}

function goHome() {
    navigateTo('tecnicos');
}